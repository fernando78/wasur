<?php
/* konfigurasi development */
$host="localhost"; $user="root"; $pass=""; $db="dbwasur";
/* konfigurasi server */
//$host="153.92.4.119"; $user="prod"; $pass="mahameru1978"; $db="dbwasur";

//print "<script language='javascript'>location.href='www.tric-indonesia.com/repair.php'</script>";

$ms=mysql_pconnect($host, $user, $pass);
if (!$ms) { echo "UNDER MAINTENANCE, error connecting to database.\n".mysql_error(); }
mysql_select_db($db);
?>
