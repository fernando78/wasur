<?php
error_reporting(0);
include("koneksi.php");
include("encDec.php");
include("xFile.php");

session_unset();
session_start();

$_SESSION['sUserID']="";
$_SESSION['sUserEmail']="";
$_SESSION['sUserName']="";
$_SESSION['sUserGroupID']="";
$_SESSION['sUserGroupName']="";
$_SESSION['sUserActive']="";

if ($_POST['pUserLogin']!="") { $vEmail=$_POST['pUserLogin']; } else { $vEmail=""; }
if ($_POST['pPasswordLogin']!="") { $vPassword=$_POST['pPasswordLogin']; } else { $vPassword=""; }

$qCekLogin= "SELECT a.id, a.email, a.phone, a.name, a.active, a.groupid,
				(SELECT name FROM admgroup WHERE id = a.groupid) nm_group
			FROM admuser a, admgroup b
			WHERE a.groupid = b.id
			AND a.email = '".cleanQuery(strtolower($vEmail))."'
			AND a.password = '".cleanQuery($vPassword)."'
			LIMIT 1 ";
$rsLogin=mysql_query($qCekLogin) or die(mysql_error());
$ctLogin=mysql_num_rows($rsLogin);

if ( $ctLogin > 0 ) {
	while( $rwLogin=mysql_fetch_array($rsLogin) ) {
		if( $rwLogin['active']=="N" ) { print "<script language='javascript'>location.href='../index.php'</script>"; }
		$_SESSION['sUserID'] = fEnc($rwLogin['id']);
		$_SESSION['sUserEmail'] = fEnc(strtolower($vEmail));
		$_SESSION['sUserName'] = fEnc($rwLogin['name']);
		$_SESSION['sUserGroupID'] = fEnc($rwLogin['groupid']);
		$_SESSION['sUserGroupName'] = fEnc($rwLogin['nm_group']);
		$_SESSION['sUserActive'] = fEnc($rwLogin['active']);

		print "<script language='javascript'>location.href='../index.php?pPage=".fEnc("home")."'</script>";
		}
	mysql_free_result($rsLogin);
	}
else {
	print "<script language='javascript'>alert('User belum terdaftar');</script>";
	print "<script language='javascript'>location.href='../index.php'</script>";
	}
?>