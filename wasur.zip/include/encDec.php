<?php
function fEnc ($text) {
	if ($text!="") {
		$base64=base64_encode($text);
		$base64url=strtr($base64, '+/=', '-_,');
		return $base64url;
		}
	else { return ""; }
	}

function fDec ($text) {
	if ($text!="") {
		$base64url = strtr($text, '-_,', '+/=');
		$base64 = base64_decode($base64url);
		return $base64;
		}
	else { return ""; }
	}
?>