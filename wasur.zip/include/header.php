<?php
print '
<header class="clearfix">
	<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" style="padding:10px" href="#">
					<span style="color:white;font-size:12px;font-weight:500">TAMAN NASIONAL<span><br>
					<span style="color:white;font-size:28px;font-weight: 700">WASUR</span>
				</a>
			</div>
			<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				<ul class="nav navbar-nav navbar-right">
					<li><a class="active" href="index.php"><i class="fa fa-home"></i> Beranda</a></li>
					<li><a href="layanan.php"><i class="fa fa-tasks"></i> Yang Bisa Kamu Lakukan</a></li>
					<li><a href="tentangkami.php"><i class="fa fa-coffee"></i> Tentang Kami</a></li>
					<li><a href="blog.php"><i class="fa fa-file-text-o"></i> Cerita</a></li>';
					if ($_SESSION['sUserID']=="")
						{print '<li><a href="#" data-toggle="modal" data-target="#mdlLogin"><i class="fa fa-sign-in"></i> Login</a></li>';}
					else
						{print '<li><a href="#" data-toggle="modal" data-target="#mdlApps"><i class="fa fa-th"></i> Apps</a></li>';}
				print '
				</ul>
			</div>
		</div>
	</nav>
</header>

<form action="include/checkLogin.php" method="post" role="form">
	<div class="modal fade" id="mdlLogin" role="dialog">
		<div class="modal-dialog modal-sm">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Login</h4>
				</div>
				<div class="modal-body">
					<div class="input-group">
						<span class="input-group-addon" style="background-color:maroon;color:white"><i class="fa fa-user" style="width:20px"></i></span>
						<input id="pUserLogin" type="text" class="form-control" name="pUserLogin" placeholder="Username" autofocus>
					</div>
					<div style="height:10px"></div>
					<div class="input-group">
						<span class="input-group-addon" style="background-color:maroon;color:white"><i class="fa fa-key" style="width:20px"></i></span>
						<input id="pPasswordLogin" type="password" class="form-control" name="pPasswordLogin" placeholder="Password">
					</div>
				</div>
				<div class="modal-footer">
					<input type="submit" name="pSubmitLogin" class="btn btn-danger" value="Submit">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
</form>

<div class="modal fade" tabindex="-1" id="mdlApps" role="dialog">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title"><i class="fa fa-th"></i> Menu Apps</h4>
			</div>
			<div class="modal-body">

				<div class="row" style="margin:5px">
					<div class="col-md-4" style="text-align:center">
						<div class="consulting-post">
							<h4><a style="color:maroon" href="index.php?pPage='.fEnc("apps").'"><i class="fa fa-external-link"></i> Panel CMS</a></h4>
							<p>Donec odio. Quisque volutpat mattis eros. Nullam malesuada </p>
						</div>
					</div>
					<div class="col-md-4" style="text-align:center">
						<div class="consulting-post">
							<h4><a style="color:maroon" href="index.php?pPage='.fEnc("apps").'"><i class="fa fa-external-link"></i> Panel Kontributor</a></h4>
							<p>Donec odio. Quisque volutpat mattis eros. Nullam malesuada </p>
						</div>
					</div>
					<div class="col-md-4" style="text-align:center">
						<div class="consulting-post">
							<h4><a style="color:maroon" href="index.php?pPage='.fEnc("apps").'"><i class="fa fa-external-link"></i> Tamu</a></h4>
							<p>Donec odio. Quisque volutpat mattis eros. Nullam malesuada </p>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				<input type="button" name="pLogout" class="btn btn-danger" value="Logout" onclick=\'location.href="index.php?pMsg='.fEnc("OUT").'"\'>
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>';
?>