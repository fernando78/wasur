<?php
print '
<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-4">
				<div class="contact-info">
					<h2><i class="fa fa-location-arrow"></i> Alamat Kami</h2>
					<p>Taman Nasional Wasur,</br>Merauke</p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="contact-info">
					<h2><i class="fa fa-envelope-o"></i> Hubungi Kami</h2>
					<p>1223 334 3434 <br> wasur@yourcompany.com</p>
					<p><a href="contact.php">Kirim Pertanyaan?</a></p>
				</div>
			</div>
			<div class="col-md-4">
				<div class="contact-info">
					<h2><i class="fa fa-clock-o"></i> Jam Layanan</h2>
					<p>Senin s/d Jumat: 8:00 - 16:00 <br> Saturday, Sunday: 9:00 - 14:00</p>
				</div>
			</div>
		</div>
	</div>
</footer>';
?>