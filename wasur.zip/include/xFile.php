<?php
$vSiteName="Taman Nasional Wasur";

/** MENCEGAH TROUBLEMAKER - SEMOGA SAJA BERMANFAAT!!! **/
function cleanQuery($string) {
	$string=stripslashes($string);
	$string=strip_tags($string);
	$string=mysql_real_escape_string($string);
	return $string;
	}
?>