<?php
print 'Ini halaman '.fDec($_REQUEST['pPage']).'.php';
?>